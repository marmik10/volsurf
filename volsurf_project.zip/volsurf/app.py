"""SVI slice explorer: static parameter checks vs. butterfly arbitrage.

Run locally:  streamlit run app.py
"""
import numpy as np
import plotly.graph_objects as go
import streamlit as st

from volsurf.svi import RawSVI, butterfly_cost, butterfly_report, density, durrleman_g

INK = "#1F3A5F"
MUTED = "#7A8696"
VIOLATION = "#B3261E"

PRESETS = {
    "Vogt example (Gatheral & Jacquier 2014)": dict(
        a=-0.0410, b=0.1331, rho=0.3060, m=0.3586, sigma=0.4153, T=1.0),
    "Equity-index-like skew": dict(
        a=0.0100, b=0.1000, rho=-0.6000, m=0.0200, sigma=0.1500, T=1.0),
}
PARAMS = ("a", "b", "rho", "m", "sigma", "T")

st.set_page_config(page_title="SVI slice explorer", layout="wide")


def load_preset():
    for key, val in PRESETS[st.session_state.preset].items():
        st.session_state[key] = val


if "a" not in st.session_state:
    st.session_state.preset = next(iter(PRESETS))
    load_preset()

# --- controls --------------------------------------------------------------
with st.sidebar:
    st.selectbox("Load an example", list(PRESETS), key="preset", on_change=load_preset)
    st.button("Reset to this example", on_click=load_preset, width="stretch")
    st.slider("a — variance level", -0.20, 0.50, step=0.0001, format="%.4f", key="a")
    st.slider("b — wing steepness", 0.0, 1.0, step=0.0001, format="%.4f", key="b")
    st.slider("ρ — skew", -0.999, 0.999, step=0.001, format="%.3f", key="rho")
    st.slider("m — horizontal shift", -1.0, 1.0, step=0.0001, format="%.4f", key="m")
    st.slider("σ — ATM curvature", 0.001, 1.0, step=0.0001, format="%.4f", key="sigma")
    st.slider("T — years to expiry", 0.02, 5.0, step=0.01, key="T")
    k_lo, k_hi = st.slider("Log-moneyness range shown", -3.0, 3.0, (-1.5, 1.5), step=0.1)

p = {name: st.session_state[name] for name in PARAMS}
svi = RawSVI(p["a"], p["b"], p["rho"], p["m"], p["sigma"])
T = p["T"]
k = np.linspace(k_lo, k_hi, 3001)
issues = svi.validate()

# --- verdict ---------------------------------------------------------------
st.title("SVI slice explorer")
st.markdown(
    "A slice can pass every parameter sanity check and still price a butterfly "
    "below zero. The two verdicts below are computed independently."
)

col_static, col_fly = st.columns(2)
with col_static:
    st.subheader("Parameter checks")
    if issues:
        st.error("Fail: " + "; ".join(issues))
    else:
        lo, hi = svi.wing_slopes()
        st.success(
            f"Pass. Minimum total variance {svi.min_variance():.4f}; "
            f"wing slopes {lo:.3f} (puts) and {hi:.3f} (calls), both ≤ 2."
        )

report = None
if issues:
    with col_fly:
        st.subheader("Butterfly arbitrage")
        st.info("Not evaluated: fix the failed parameter checks first, since "
                "Durrleman's condition needs positive total variance.")
else:
    report = butterfly_report(svi, k)
    with col_fly:
        st.subheader("Butterfly arbitrage")
        if report["has_violation"]:
            spans = ", ".join(f"[{a:.2f}, {b:.2f}]" for a, b in report["violation_intervals"])
            st.error(f"Present. Density is negative for k in {spans}; "
                     f"minimum g = {report['min_g']:.4f} at k = {report['argmin_k']:.3f}.")
        else:
            st.success(f"None found on the displayed range. Minimum g = {report['min_g']:.4f}.")

    if report["has_violation"]:
        k0 = report["argmin_k"]
        cost = butterfly_cost(svi, k0)
        st.warning(
            f"Every parameter check passes, yet a call butterfly centred at k = {k0:.3f} "
            f"(strikes {np.exp(k0 - 0.05):.3f}, {np.exp(k0):.3f}, {np.exp(k0 + 0.05):.3f} "
            f"with forward 1) costs {cost:.2e}. A non-negative payoff with negative cost is arbitrage."
        )

st.caption("Grid checks are evidence, not proof: a violation narrower than the grid spacing "
           "or outside the displayed range would be missed.")


# --- charts ----------------------------------------------------------------
def figure(x_title, y_title):
    fig = go.Figure()
    fig.update_layout(
        template="plotly_white", height=380, showlegend=False,
        margin=dict(l=10, r=10, t=20, b=10),
        xaxis_title=x_title, yaxis_title=y_title, hovermode="x",
    )
    if report and report["has_violation"]:
        for a, b in report["violation_intervals"]:
            fig.add_vrect(x0=a, x1=b, fillcolor=VIOLATION, opacity=0.07, line_width=0)
    return fig


def line(fig, y, name, color=INK, dash=None):
    fig.add_trace(go.Scatter(x=k, y=y, name=name, mode="lines",
                             line=dict(color=color, width=2, dash=dash)))


def negative_fill(fig, y):
    fig.add_trace(go.Scatter(x=k, y=np.minimum(y, 0), mode="lines", hoverinfo="skip",
                             line=dict(width=0), fill="tozeroy",
                             fillcolor="rgba(179,38,30,0.35)"))


tab_smile, tab_g, tab_density, tab_surface = st.tabs(
    ["Smile", "Durrleman condition", "Implied density", "3D surface"])

w = svi.w(k)
with tab_smile:
    left, right = st.columns(2)
    with left:
        fig = figure("log-moneyness k = log(K/F)", "implied volatility")
        iv = np.where(w > 0, np.sqrt(np.clip(w, 0, None) / T), np.nan)
        line(fig, iv, "implied vol")
        fig.update_yaxes(tickformat=".0%")
        st.plotly_chart(fig, width="stretch")
    with right:
        fig = figure("log-moneyness k", "total variance w = σ²T")
        line(fig, w, "total variance")
        fig.add_hline(y=0, line_color=MUTED, line_width=1)
        st.plotly_chart(fig, width="stretch")
    st.caption("A smooth, convex-looking smile says nothing about arbitrage on its own. "
               "Compare with the next two tabs.")

if issues:
    for tab in (tab_g, tab_density):
        with tab:
            st.info("Shown once the parameter checks pass.")
else:
    with tab_g:
        g = durrleman_g(svi, k)
        fig = figure("log-moneyness k", "g(k)")
        negative_fill(fig, g)
        line(fig, g, "g(k)")
        fig.add_hline(y=0, line_color=MUTED, line_width=1)
        st.plotly_chart(fig, width="stretch")
        st.caption("The slice is free of butterfly arbitrage if and only if g(k) ≥ 0 everywhere.")

    with tab_density:
        dens = density(svi, k)
        fig = figure("log-moneyness k", "density of k")
        negative_fill(fig, dens)
        line(fig, dens, "density")
        fig.add_hline(y=0, line_color=MUTED, line_width=1)
        st.plotly_chart(fig, width="stretch")
        st.caption(f"Mass on the displayed range: {np.trapezoid(dens, k):.4f}. "
                   "Negative regions mean some butterfly has negative price.")

with tab_surface:
    st.info("The calibrated SPX surface arrives with checkpoint 4. A single slice has no "
            "maturity dimension, and a 3D plot cannot reveal the arbitrage shown in the other tabs.")

with st.expander("Formulas"):
    st.latex(r"w(k) = a + b\left[\rho(k-m) + \sqrt{(k-m)^2 + \sigma^2}\right]")
    st.latex(r"g(k) = \left(1 - \frac{k w'}{2w}\right)^2 - \frac{w'^2}{4}\left(\frac{1}{w} + \frac14\right) + \frac{w''}{2}")
    st.latex(r"p(k) = \frac{g(k)}{\sqrt{2\pi w(k)}}\exp\!\left(-\frac{d_-(k)^2}{2}\right), \quad d_- = -\frac{k}{\sqrt{w}} - \frac{\sqrt{w}}{2}")
    st.markdown("Reference: J. Gatheral and A. Jacquier (2014), *Arbitrage-free SVI volatility surfaces*, "
                "Quantitative Finance 14(1).")
