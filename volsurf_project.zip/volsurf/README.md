# Equity Volatility Surface Engineering
Calibration, arbitrage diagnostics and model validation.

## Conventions
- `k = log(K/F)` (forward log-moneyness), `s = σ√T`, `w = s²` (total implied variance)
- Normalized prices are undiscounted and divided by the forward: `c = C/(D·F)`
- IV inversion always runs on the OTM side; ITM inputs are converted via parity and flagged when that loses precision

## App
```
pip install -r requirements.txt
streamlit run app.py
```
Page 1 is an SVI slice explorer. It shows parameter checks and Durrleman's butterfly condition side by side, and prices the arbitrage butterfly when one exists. It uses no market data, so it is safe to deploy publicly.

To deploy on Streamlit Community Cloud, push this folder to GitHub and set the entry point to `app.py`.

## Checkpoint 1 — verify the mathematics ✅
Run `python -m pytest -q` (20 tests).

| Check | Result |
|---|---|
| OTM IV round-trip, ≤12 std devs of moneyness, T from 1 week to 3y, σ from 5% to 100% | relative error ≤ 1e-11 |
| OTM beyond ~12 std devs | price underflows → `nonpositive_time_value` (correct refusal) |
| ITM via parity, 5–12 std devs | errors up to 9% → now flagged `itm_low_precision`; no `ok` result is wrong by more than 2e-11 |
| SVI `w'`, `w''` vs finite differences | agree to ~1e-8 |
| Durrleman density vs Breeden–Litzenberger `∂²C/∂K²` | agree to ~1e-6, including where the density is negative |
| Valid slice density integral | 1 within 1e-8 |

### Vogt example (Gatheral–Jacquier 2014, T=1)
`a=-0.0410, b=0.1331, ρ=0.3060, m=0.3586, σ=0.4153`
- Passes every static parameter check (positive minimum variance, Lee bound)
- Durrleman g < 0 on k ∈ [0.64, 1.26], minimum −0.033 at k ≈ 0.88
- A butterfly centred at k = 0.88 has negative cost: the arbitrage is tradeable, not just a diagnostic artefact

> Parameters entered from memory of the paper. Verify against the published table before claiming reproduction.

## Findings worth keeping
1. **Parity conversion of deep-ITM quotes silently corrupts IV.** This is the concrete reason to calibrate on OTM quotes, not just convention.
2. **Static SVI parameter checks are necessary, not sufficient.** Vogt passes them all and still has negative density.
3. **Test design matters.** Second-order finite differences of `w` at h=1e-5 have rounding noise (~ε·w/h²) larger than the quantity being checked. Differencing the analytic `w'` fixes it.

## Next: Checkpoint 2
Reproduce the Gatheral–Jacquier repair of the Vogt slice (SVI-JW reparametrisation, adjust the call-wing and minimum-variance parameters) and match the published parameters and g(k) curve.
