from streamlit.testing.v1 import AppTest
from pathlib import Path
APP = str(Path(__file__).resolve().parents[1] / "app.py")


def run(**overrides):
    at = AppTest.from_file(APP, default_timeout=30)
    at.run()
    for key, val in overrides.items():
        at.slider(key=key).set_value(val)
    if overrides:
        at.run()
    assert not at.exception, at.exception
    return at


def test_vogt_default_shows_static_pass_and_arbitrage():
    at = run()
    assert any(s.value.startswith("Pass.") for s in at.success)
    assert any(e.value.startswith("Present.") for e in at.error)
    assert len(at.warning) == 1 and "costs -" in at.warning[0].value


def test_clean_preset_has_no_arbitrage():
    at = AppTest.from_file(APP, default_timeout=30)
    at.run()
    at.selectbox(key="preset").set_value("Equity-index-like skew").run()
    assert not at.exception
    assert not at.warning
    assert any(s.value.startswith("None found") for s in at.success)


def test_invalid_parameters_handled():
    at = run(a=-0.2)   # negative minimum variance
    assert any("negative minimum total variance" in e.value for e in at.error)


def test_reset_restores_example():
    at = run(a=0.1)
    at.button[0].click().run()
    assert at.slider(key="a").value == -0.0410
    assert len(at.warning) == 1
