import numpy as np
import pytest

from volsurf.black import black_price, black_vega, implied_vol

T_GRID = [7 / 365, 30 / 365, 0.25, 1.0, 3.0]
SIG_GRID = [0.05, 0.15, 0.4, 1.0]
K_GRID = np.linspace(-2, 2, 81)


def test_put_call_parity():
    F, D, T = 100.0, 0.97, 0.5
    K = np.linspace(50, 150, 21)
    c = black_price(F, K, T, 0.25, D, is_call=True)
    p = black_price(F, K, T, 0.25, D, is_call=False)
    np.testing.assert_allclose(c - p, D * (F - K), atol=1e-12)


def test_vega_matches_finite_difference():
    F, K, T, sig, h = 100.0, 110.0, 0.75, 0.3, 1e-6
    fd = (black_price(F, K, T, sig + h) - black_price(F, K, T, sig - h)) / (2 * h)
    assert black_vega(F, K, T, sig) == pytest.approx(fd, rel=1e-7)


def test_otm_roundtrip_within_12_std():
    """OTM inversion recovers sigma to ~1e-12 out to 12 std devs of moneyness."""
    for T in T_GRID:
        for sig in SIG_GRID:
            for k in K_GRID:
                if abs(k) / (sig * np.sqrt(T)) > 12:
                    continue
                is_call = k >= 0
                pr = black_price(1.0, np.exp(k), T, sig, is_call=is_call)
                iv, st = implied_vol(pr, 1.0, np.exp(k), T, is_call=is_call, return_status=True)
                assert st == "ok", (T, sig, k, st)
                assert iv == pytest.approx(sig, rel=1e-11)


def test_ok_status_is_never_silently_wrong():
    """Any result labelled 'ok' -- OTM or ITM, anywhere on the grid -- is accurate."""
    for T in T_GRID:
        for sig in SIG_GRID:
            for k in K_GRID:
                for is_call in (True, False):
                    pr = black_price(1.0, np.exp(k), T, sig, is_call=is_call)
                    iv, st = implied_vol(pr, 1.0, np.exp(k), T, is_call=is_call, return_status=True)
                    if st == "ok":
                        assert iv == pytest.approx(sig, rel=1e-10), (T, sig, k, is_call)


def test_deep_itm_flagged():
    # 8 std devs ITM call: parity conversion destroys the time value
    T, sig = 30 / 365, 0.15
    k = -8 * sig * np.sqrt(T)
    pr = black_price(1.0, np.exp(k), T, sig, is_call=True)
    _, st = implied_vol(pr, 1.0, np.exp(k), T, is_call=True, return_status=True)
    assert st in ("itm_low_precision", "nonpositive_time_value")


@pytest.mark.parametrize(
    "price,is_call,expected",
    [
        (-1.0, True, "nonpositive_time_value"),
        (5.0, True, "nonpositive_time_value"),     # below intrinsic of 10 (K=90)
        (100.0, True, "above_upper_bound"),        # call >= D*F
    ],
)
def test_arbitrage_violating_prices_rejected(price, is_call, expected):
    K = 90.0 if price == 5.0 else 100.0
    iv, st = implied_vol(price, 100.0, K, 1.0, is_call=is_call, return_status=True)
    assert np.isnan(iv) and st == expected


def test_discounting_handled():
    F, K, T, D, sig = 4500.0, 4300.0, 0.4, 0.98, 0.21
    pr = black_price(F, K, T, sig, D, is_call=False)
    assert implied_vol(pr, F, K, T, D, is_call=False) == pytest.approx(sig, rel=1e-12)
