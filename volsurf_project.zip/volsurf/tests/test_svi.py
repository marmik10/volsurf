import numpy as np
import pytest

from volsurf.black import normalized_call
from volsurf.svi import RawSVI, butterfly_cost, butterfly_report, density, durrleman_g

GOOD = RawSVI(a=0.04, b=0.4, rho=-0.4, m=0.0, sigma=0.2)
# Axel Vogt's example, Gatheral & Jacquier (2014), T = 1
VOGT = RawSVI(a=-0.0410, b=0.1331, rho=0.3060, m=0.3586, sigma=0.4153)


@pytest.mark.parametrize("svi", [GOOD, VOGT])
def test_analytic_derivatives_match_finite_differences(svi):
    k, h = np.linspace(-2, 2, 201), 1e-5
    fd1 = (svi.w(k + h) - svi.w(k - h)) / (2 * h)
    # Difference the analytic first derivative for w'': a second-order
    # difference of w itself has rounding noise ~eps*w/h^2, too large here.
    fd2 = (svi.dw(k + h) - svi.dw(k - h)) / (2 * h)
    np.testing.assert_allclose(svi.dw(k), fd1, rtol=1e-8, atol=1e-9)  # dw crosses zero
    np.testing.assert_allclose(svi.d2w(k), fd2, rtol=1e-7, atol=1e-10)


def _density_from_prices(svi, k, h=1e-4):
    """Breeden-Litzenberger: density of K is d2c/dK2 (F=1, undiscounted);
    density of k = log K is that times K."""
    K = np.exp(k)
    c = lambda K: normalized_call(np.log(K), np.sqrt(svi.w(np.log(K))))
    return (c(K + h) - 2 * c(K) + c(K - h)) / h ** 2 * K


@pytest.mark.parametrize("svi,k", [(GOOD, np.linspace(-1, 1, 41)),
                                   (VOGT, np.linspace(0.7, 1.2, 11))])
def test_g_density_agrees_with_price_convexity(svi, k):
    """The Durrleman-based density must equal the second strike derivative of
    call prices -- including where it is negative (the Vogt case)."""
    np.testing.assert_allclose(density(svi, k), _density_from_prices(svi, k),
                               rtol=1e-4, atol=1e-8)


def test_valid_slice_density_integrates_to_one():
    k = np.linspace(-40, 40, 400_001)
    assert np.trapezoid(density(GOOD, k), k) == pytest.approx(1.0, abs=1e-8)
    assert butterfly_report(GOOD)["has_violation"] is False


def test_vogt_passes_static_checks_but_has_butterfly_arbitrage():
    # The point of the example: parameter sanity checks are not enough.
    assert VOGT.validate() == []
    assert VOGT.min_variance() > 0
    rep = butterfly_report(VOGT, np.linspace(-1.5, 1.5, 30_001))
    assert rep["has_violation"]
    assert rep["min_g"] == pytest.approx(-0.0329, abs=5e-4)
    assert rep["argmin_k"] == pytest.approx(0.879, abs=5e-3)
    (lo, hi), = rep["violation_intervals"]
    assert lo == pytest.approx(0.64, abs=0.01) and hi == pytest.approx(1.26, abs=0.01)


def test_vogt_negative_density_shows_up_as_butterfly_with_negative_price():
    """Make the arbitrage tradeable: a butterfly centred in the bad region
    has negative cost under the Vogt slice, positive under a clean slice."""
    assert butterfly_cost(VOGT, 0.88) < 0
    assert butterfly_cost(GOOD, 0.0) > 0


@pytest.mark.parametrize("params,msg", [
    (dict(a=0.04, b=-0.1, rho=0.0, m=0.0, sigma=0.2), "b < 0"),
    (dict(a=0.04, b=0.1, rho=1.0, m=0.0, sigma=0.2), "|rho| >= 1"),
    (dict(a=-0.5, b=0.1, rho=0.0, m=0.0, sigma=0.2), "negative minimum total variance"),
    (dict(a=0.04, b=1.8, rho=0.5, m=0.0, sigma=0.2), "Lee moment bound violated (wing slope > 2)"),
])
def test_validate_catches_bad_parameters(params, msg):
    assert msg in RawSVI(**params).validate()
