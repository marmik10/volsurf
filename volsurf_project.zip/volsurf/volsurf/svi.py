"""Raw SVI slice: total variance, analytic derivatives, and butterfly diagnostics.

w(k) = a + b * (rho * (k - m) + sqrt((k - m)^2 + sigma^2))

References: Gatheral & Jacquier (2014), "Arbitrage-free SVI volatility surfaces".
"""
from __future__ import annotations

from dataclasses import dataclass

import numpy as np


@dataclass(frozen=True)
class RawSVI:
    a: float
    b: float
    rho: float
    m: float
    sigma: float

    # --- total variance and derivatives in k ---------------------------------
    def _r(self, k):
        x = np.asarray(k, float) - self.m
        return x, np.sqrt(x * x + self.sigma ** 2)

    def w(self, k):
        x, r = self._r(k)
        return self.a + self.b * (self.rho * x + r)

    def dw(self, k):
        x, r = self._r(k)
        return self.b * (self.rho + x / r)

    def d2w(self, k):
        _, r = self._r(k)
        return self.b * self.sigma ** 2 / r ** 3

    def implied_vol(self, k, T):
        return np.sqrt(self.w(k) / T)

    # --- static parameter checks ---------------------------------------------
    def min_variance(self):
        """Minimum of w over k (attained at k* = m - rho*sigma/sqrt(1-rho^2))."""
        return self.a + self.b * self.sigma * np.sqrt(1.0 - self.rho ** 2)

    def wing_slopes(self):
        """Asymptotic slopes of w as k -> -inf and k -> +inf."""
        return self.b * (1.0 - self.rho), self.b * (1.0 + self.rho)

    def validate(self):
        """Return a list of violated conditions (empty list == passes).

        These are necessary conditions only. Passing them does NOT rule out
        butterfly arbitrage; use durrleman_g for that.
        """
        issues = []
        if self.b < 0:
            issues.append("b < 0")
        if not abs(self.rho) < 1:
            issues.append("|rho| >= 1")
        if self.sigma <= 0:
            issues.append("sigma <= 0")
        if not issues and self.min_variance() < 0:
            issues.append("negative minimum total variance")
        if not issues and max(self.wing_slopes()) > 2:
            issues.append("Lee moment bound violated (wing slope > 2)")
        return issues


def durrleman_g(svi: RawSVI, k):
    """Durrleman's condition. The slice is free of butterfly arbitrage iff
    g(k) >= 0 for all k (given w > 0 and d_+ -> -inf as k -> +inf)."""
    k = np.asarray(k, float)
    w, w1, w2 = svi.w(k), svi.dw(k), svi.d2w(k)
    return (1.0 - k * w1 / (2.0 * w)) ** 2 - 0.25 * w1 ** 2 * (1.0 / w + 0.25) + 0.5 * w2


def density(svi: RawSVI, k):
    """Risk-neutral density of k = log(K/F) implied by the slice.
    Negative values indicate butterfly arbitrage."""
    k = np.asarray(k, float)
    w = svi.w(k)
    d_minus = -k / np.sqrt(w) - 0.5 * np.sqrt(w)
    return durrleman_g(svi, k) / np.sqrt(2.0 * np.pi * w) * np.exp(-0.5 * d_minus ** 2)


def butterfly_report(svi: RawSVI, k_grid=None):
    """Grid diagnostic. A clean grid result is evidence, not proof."""
    if k_grid is None:
        k_grid = np.linspace(-3.0, 3.0, 6001)
    g = durrleman_g(svi, k_grid)
    neg = g < 0
    report = {
        "min_g": float(g.min()),
        "argmin_k": float(k_grid[np.argmin(g)]),
        "has_violation": bool(neg.any()),
        "violation_intervals": [],
    }
    if neg.any():
        edges = np.flatnonzero(np.diff(neg.astype(int)))
        starts = [0] if neg[0] else []
        ends = [len(neg)] if neg[-1] else []
        idx = np.concatenate((starts, edges + 1, ends)).astype(int)
        for lo, hi in zip(idx[::2], idx[1::2]):
            report["violation_intervals"].append((float(k_grid[lo]), float(k_grid[hi - 1])))
    return report


def butterfly_cost(svi: RawSVI, k0: float, dk: float = 0.05):
    """Normalized cost (F=1, undiscounted) of a unit-height tent payoff centred
    at K0 = exp(k0), built from calls at exp(k0 - dk), exp(k0), exp(k0 + dk).
    A negative cost means the slice admits a tradeable butterfly arbitrage."""
    from .black import normalized_call

    K = np.exp(np.array([k0 - dk, k0, k0 + dk]))
    c = normalized_call(np.log(K), np.sqrt(svi.w(np.log(K))))
    w_lo, w_hi = 1.0 / (K[1] - K[0]), 1.0 / (K[2] - K[1])
    return float(w_lo * c[0] - (w_lo + w_hi) * c[1] + w_hi * c[2])
