"""Black-76 pricing and implied-volatility inversion, expressed in forward terms.

Conventions
-----------
k = log(K / F)            forward log-moneyness
s = sigma * sqrt(T)       total standard deviation
w = s**2                  total implied variance
Normalized prices are undiscounted and divided by the forward: c = C / (D * F).
In these units put-call parity is c - p = 1 - exp(k).
"""
from __future__ import annotations

import numpy as np
from scipy.optimize import brentq
from scipy.special import ndtr

_S_MIN = 1e-12
_ITM_NOISE_TOL = 1e-9


def _d1d2(k, s):
    d1 = -k / s + 0.5 * s
    return d1, d1 - s


def _price(k, s, kind):
    k, s = np.broadcast_arrays(np.asarray(k, float), np.asarray(s, float))
    shape = k.shape
    k, s = k.ravel(), s.ravel()
    ek = np.exp(k)
    out = np.maximum(1.0 - ek, 0.0) if kind == "call" else np.maximum(ek - 1.0, 0.0)
    pos = s > 0
    d1, d2 = _d1d2(k[pos], s[pos])
    if kind == "call":
        out[pos] = ndtr(d1) - ek[pos] * ndtr(d2)
    else:
        out[pos] = ek[pos] * ndtr(-d2) - ndtr(-d1)
    out = out.reshape(shape)
    return float(out) if out.ndim == 0 else out


def normalized_call(k, s):
    """c = C/(D F). Direct formula; loses relative precision for deep ITM calls."""
    return _price(k, s, "call")


def normalized_put(k, s):
    """p = P/(D F). Computed directly (not via parity) to keep OTM-put precision."""
    return _price(k, s, "put")


def black_price(F, K, T, sigma, D=1.0, is_call=True):
    """Discounted Black-76 price."""
    k = np.log(np.asarray(K, float) / F)
    s = np.asarray(sigma, float) * np.sqrt(T)
    norm = normalized_call(k, s) if is_call else normalized_put(k, s)
    return D * F * norm


def black_vega(F, K, T, sigma, D=1.0):
    """dPrice/dsigma (same for calls and puts)."""
    k = np.log(np.asarray(K, float) / F)
    s = np.asarray(sigma, float) * np.sqrt(T)
    d1, _ = _d1d2(k, s)
    return D * F * np.exp(-0.5 * d1 * d1) / np.sqrt(2 * np.pi) * np.sqrt(T)


def implied_vol(price, F, K, T, D=1.0, is_call=True, return_status=False):
    """Invert Black-76 for one option.

    Inversion always runs on the OTM side (call if K >= F, put otherwise).
    ITM inputs are converted via parity, which discards precision when the
    ITM price is mostly intrinsic -- one reason to calibrate on OTM quotes.

    Returns nan (and a status string if requested) when the price violates
    no-arbitrage bounds or the solver cannot bracket a root.
    """
    def done(vol, status):
        return (vol, status) if return_status else vol

    if not (T > 0 and F > 0 and K > 0 and D > 0):
        return done(np.nan, "bad_inputs")
    k = np.log(K / F)
    p = price / (D * F)
    intrinsic_shift = 1.0 - np.exp(k)  # c - p
    otm_call = k >= 0
    if otm_call:
        target = p if is_call else p + intrinsic_shift
        upper, fn = 1.0, normalized_call
    else:
        target = p if not is_call else p - intrinsic_shift
        upper, fn = np.exp(k), normalized_put

    if not np.isfinite(target) or target <= 0:
        return done(np.nan, "nonpositive_time_value")
    if target >= upper:
        return done(np.nan, "above_upper_bound")
    # Parity conversion of an ITM price leaves rounding noise of order
    # eps * price in the OTM-equivalent price. When that noise is large
    # relative to the time value, the IV is unreliable: flag it rather than
    # return a silently wrong number with status "ok".
    converted = is_call != otm_call
    low_precision = converted and np.finfo(float).eps * abs(p) / target > _ITM_NOISE_TOL

    # Solve in log-price space for uniform relative accuracy across the wings.
    log_target = np.log(target)

    def f(s):
        v = fn(k, s)
        # Underflowed prices map to a large finite negative so Brent still
        # sees a sign change; f is monotone increasing in s.
        return (np.log(v) if v > 0 else -1e300) - log_target

    s_lo, s_hi = 1e-8, 1.0
    while f(s_hi) < 0:
        s_hi *= 2.0
        if s_hi > 50:
            return done(np.nan, "no_bracket_high")
    while f(s_lo) > 0:
        s_lo *= 0.1
        if s_lo < _S_MIN:
            return done(np.nan, "no_bracket_low")

    s = brentq(f, s_lo, s_hi, xtol=1e-16, rtol=4 * np.finfo(float).eps, maxiter=500)
    return done(s / np.sqrt(T), "itm_low_precision" if low_precision else "ok")
